import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    void createContactSuccess() {
        Contact c = new Contact("1", "Amy", "Marquis", "6034013504", "88 Walnut Hill Rd");
        assertEquals("1", c.getContactId());
        assertEquals("Amy", c.getFirstName());
        assertEquals("Marquis", c.getLastName());
        assertEquals("6034013504", c.getPhone());
        assertEquals("88 Walnut Hill Rd", c.getAddress());
    }

    @Test
    void contactIdNullFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "Amy", "Marquis", "6034013504", "88 Walnut Hill Rd"));
    }

    @Test
    void contactIdTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345678901", "Amy", "Marquis", "6034013504", "88 Walnut Hill Rd"));
    }

    @Test
    void firstNameNullFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", null, "Marquis", "6034013504", "88 Walnut Hill Rd"));
    }

    @Test
    void firstNameTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "ThisNameIsTooLong", "Marquis", "6034013504", "88 Walnut Hill Rd"));
    }

    @Test
    void lastNameNullFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "Amy", null, "6034013504", "88 Walnut Hill Rd"));
    }

    @Test
    void lastNameTooLongFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "Amy", "ThisLastNameIsTooLong", "6034013504", "88 Walnut Hill Rd"));
    }

    @Test
    void phoneNullFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "Amy", "Marquis", null, "88 Walnut Hill Rd"));
    }

    @Test
    void phoneNotTenDigitsFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "Amy", "Marquis", "123", "88 Walnut Hill Rd"));
    }

    @Test
    void phoneHasLettersFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "Amy", "Marquis", "60340abcde", "88 Walnut Hill Rd"));
    }

    @Test
    void addressNullFails() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "Amy", "Marquis", "6034013504", null));
    }

    @Test
    void addressTooLongFails() {
        String tooLong = "1234567890123456789012345678901"; // 31 chars
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "Amy", "Marquis", "6034013504", tooLong));
    }

    @Test
    void contactIdNotUpdatable() {
        Contact c = new Contact("A1", "Amy", "Marquis", "6034013504", "88 Walnut Hill Rd");
        c.setFirstName("Amye");
        assertEquals("A1", c.getContactId()); // still the same
    }
}
