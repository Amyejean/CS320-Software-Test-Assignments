

import java.util.Date;

public class Appointment {

    private final String appointmentId;   // not updatable
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.trim().isEmpty() || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must not be null/empty and must be <= 10 characters.");
        }
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date must not be null.");
        }
        // Requirement: cannot be in the past; use before(new Date())
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        }
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description must not be null/empty and must be <= 50 characters.");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = new Date(appointmentDate.getTime());
        this.description = description;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime()); // defensive copy
    }

    public String getDescription() {
        return description;
    }

    // Not required by your prompt, but safe/useful if you later need updates:
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date must not be null.");
        }
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        }
        this.appointmentDate = new Date(appointmentDate.getTime());
    }

    public void setDescription(String description) {
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description must not be null/empty and must be <= 50 characters.");
        }
        this.description = description;
    }
}