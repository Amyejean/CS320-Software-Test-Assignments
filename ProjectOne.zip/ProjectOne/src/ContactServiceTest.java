import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    void addContactSuccess() {
        ContactService service = new ContactService();
        service.addContact("1", "Amy", "Marquis", "6034013504", "88 Walnut Hill Rd");
        assertEquals(1, service.size());
        assertNotNull(service.getContact("1"));
    }

    @Test
    void addDuplicateIdFails() {
        ContactService service = new ContactService();
        service.addContact("1", "Amy", "Marquis", "6034013504", "88 Walnut Hill Rd");

        assertThrows(IllegalArgumentException.class, () ->
                service.addContact("1", "Chris", "Ayer", "6031112222", "Some Address"));
    }

    @Test
    void deleteContactSuccess() {
        ContactService service = new ContactService();
        service.addContact("1", "Amy", "Marquis", "6034013504", "88 Walnut Hill Rd");

        service.deleteContact("1");
        assertEquals(0, service.size());
        assertNull(service.getContact("1"));
    }

    @Test
    void deleteNonExistentFails() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999"));
    }

    @Test
    void updateContactSuccess() {
        ContactService service = new ContactService();
        service.addContact("1", "Amy", "Marquis", "6034013504", "88 Walnut Hill Rd");

        service.updateContact("1", "Amye", "Marquis", "6039998888", "New Address 123");

        Contact updated = service.getContact("1");
        assertEquals("1", updated.getContactId());
        assertEquals("Amye", updated.getFirstName());
        assertEquals("Marquis", updated.getLastName());
        assertEquals("6039998888", updated.getPhone());
        assertEquals("New Address 123", updated.getAddress());
    }

    @Test
    void updateNonExistentFails() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () ->
                service.updateContact("1", "Amy", "Marquis", "6034013504", "88 Walnut Hill Rd"));
    }

    @Test
    void updateInvalidPhoneFails() {
        ContactService service = new ContactService();
        service.addContact("1", "Amy", "Marquis", "6034013504", "88 Walnut Hill Rd");

        assertThrows(IllegalArgumentException.class, () ->
                service.updateContact("1", "Amy", "Marquis", "123", "88 Walnut Hill Rd"));
    }
}
