

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testTaskCreationValid() {
        Task task = new Task("1", "Task Name", "Task Description");

        assertEquals("1", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }

    @Test
    void testTaskIdNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task Name", "Task Description");
        });
    }

    @Test
    void testTaskIdTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task Name", "Task Description");
        });
    }

    @Test
    void testNameNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", null, "Task Description");
        });
    }

    @Test
    void testNameTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "ThisTaskNameIsWayTooLongToBeValid", "Task Description");
        });
    }

    @Test
    void testDescriptionNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "Task Name", null);
        });
    }

    @Test
    void testDescriptionTooLongThrowsException() {
        String longDescription = "A".repeat(51);
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "Task Name", longDescription);
        });
    }

    @Test
    void testSetNameValid() {
        Task task = new Task("1", "Old Name", "Task Description");
        task.setName("New Name");

        assertEquals("New Name", task.getName());
    }

    @Test
    void testSetDescriptionValid() {
        Task task = new Task("1", "Task Name", "Old Description");
        task.setDescription("New Description");

        assertEquals("New Description", task.getDescription());
    }
}