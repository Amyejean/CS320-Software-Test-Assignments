

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    void createAppointment_validInputs_shouldSucceed() {
        Date future = new Date(System.currentTimeMillis() + 60_000); // +1 minute
        Appointment appt = new Appointment("A123", future, "Annual checkup");
        assertEquals("A123", appt.getAppointmentId());
        assertEquals("Annual checkup", appt.getDescription());
        assertNotNull(appt.getAppointmentDate());
    }

    @Test
    void createAppointment_idNull_shouldThrow() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment(null, future, "Desc"));
    }

    @Test
    void createAppointment_idTooLong_shouldThrow() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("12345678901", future, "Desc")); // 11 chars
    }

    @Test
    void createAppointment_dateNull_shouldThrow() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A123", null, "Desc"));
    }

    @Test
    void createAppointment_dateInPast_shouldThrow() {
        Date past = new Date(System.currentTimeMillis() - 60_000); // -1 minute
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A123", past, "Desc"));
    }

    @Test
    void createAppointment_descriptionNull_shouldThrow() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A123", future, null));
    }

    @Test
    void createAppointment_descriptionTooLong_shouldThrow() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51 chars
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A123", future, longDesc));
    }
}
