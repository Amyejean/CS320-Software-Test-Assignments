import java.util.HashMap;
import java.util.Map;

public class ContactService {

    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("contact cannot be null");
        }
        String id = contact.getContactId();
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("contactId already exists");
        }
        contacts.put(id, contact);
    }

    // Optional convenience method
    public void addContact(String contactId, String firstName, String lastName, String phone, String address) {
        addContact(new Contact(contactId, firstName, lastName, phone, address));
    }

    public void deleteContact(String contactId) {
        if (contactId == null) {
            throw new IllegalArgumentException("contactId cannot be null");
        }
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("contactId not found");
        }
        contacts.remove(contactId);
    }

    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contactId == null) {
            throw new IllegalArgumentException("contactId cannot be null");
        }
        Contact existing = contacts.get(contactId);
        if (existing == null) {
            throw new IllegalArgumentException("contactId not found");
        }

        // All fields are required, so we enforce not-null here through setters
        existing.setFirstName(firstName);
        existing.setLastName(lastName);
        existing.setPhone(phone);
        existing.setAddress(address);
    }

    // Helpers for testing
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }

    public int size() {
        return contacts.size();
    }
}
