

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    @Test
    void addAppointment_uniqueId_shouldAdd() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 60_000);

        Appointment appt = new Appointment("A1", future, "Dental cleaning");
        service.addAppointment(appt);

        assertNotNull(service.getAppointment("A1"));
        assertEquals("Dental cleaning", service.getAppointment("A1").getDescription());
    }

    @Test
    void addAppointment_duplicateId_shouldThrow() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 60_000);

        service.addAppointment(new Appointment("A1", future, "First appt"));
        assertThrows(IllegalArgumentException.class,
                () -> service.addAppointment(new Appointment("A1", future, "Second appt")));
    }

    @Test
    void deleteAppointment_existingId_shouldRemove() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 60_000);

        service.addAppointment(new Appointment("A1", future, "To be deleted"));
        service.deleteAppointment("A1");

        assertNull(service.getAppointment("A1"));
    }

    @Test
    void deleteAppointment_nonExistingId_shouldNotThrow() {
        AppointmentService service = new AppointmentService();
        assertDoesNotThrow(() -> service.deleteAppointment("NOPE"));
    }

    @Test
    void deleteAppointment_nullId_shouldThrow() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
    }
}