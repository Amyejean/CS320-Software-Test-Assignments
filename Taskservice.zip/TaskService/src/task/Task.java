package task;

public class Task {
    private final String taskId;   // required, <=10, not null, NOT updatable
    private String name;           // required, <=20, not null
    private String description;    // required, <=50, not null

    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.isBlank() || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID must not be null/blank and must be 10 characters or less.");
        }
        if (name == null || name.isBlank() || name.length() > 20) {
            throw new IllegalArgumentException("Name must not be null/blank and must be 20 characters or less.");
        }
        if (description == null || description.isBlank() || description.length() > 50) {
            throw new IllegalArgumentException("Description must not be null/blank and must be 50 characters or less.");
        }
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() { return taskId; }
    public String getName() { return name; }
    public String getDescription() { return description; }

    public void setName(String name) {
        if (name == null || name.isBlank() || name.length() > 20) {
            throw new IllegalArgumentException("Name must not be null/blank and must be 20 characters or less.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.isBlank() || description.length() > 50) {
            throw new IllegalArgumentException("Description must not be null/blank and must be 50 characters or less.");
        }
        this.description = description;
    }
}