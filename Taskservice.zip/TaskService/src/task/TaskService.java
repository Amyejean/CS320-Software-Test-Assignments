package task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();

    // Add a task with a unique ID
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }

        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists.");
        }

        tasks.put(task.getTaskId(), task);
    }

    // Delete a task by task ID
    public void deleteTask(String taskId) {
        if (taskId == null || taskId.isBlank()) {
            throw new IllegalArgumentException("Task ID cannot be null or blank.");
        }

        tasks.remove(taskId);
    }

    // Update task name and description by task ID
    public void updateTask(String taskId, String name, String description) {
        if (taskId == null || taskId.isBlank()) {
            throw new IllegalArgumentException("Task ID cannot be null or blank.");
        }

        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found.");
        }

        if (name == null || description == null) {
            throw new IllegalArgumentException("Name and description cannot be null.");
        }

        task.setName(name);
        task.setDescription(description);
    }

    // Helper method for unit tests
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    // Helper method for unit tests
    public int size() {
        return tasks.size();
    }
}