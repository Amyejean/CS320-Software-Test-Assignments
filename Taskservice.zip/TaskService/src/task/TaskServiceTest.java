package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddTaskWithUniqueId() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Task Name", "Task Description");

        service.addTask(task);

        assertEquals(1, service.size());
        assertNotNull(service.getTask("1"));
    }

    @Test
    void testAddDuplicateTaskIdThrowsException() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Task Name", "Task Description"));

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(new Task("1", "Another Name", "Another Description"));
        });
    }

    @Test
    void testDeleteTaskById() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Task Name", "Task Description"));

        service.deleteTask("1");

        assertEquals(0, service.size());
        assertNull(service.getTask("1"));
    }

    @Test
    void testUpdateTaskNameAndDescription() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Old Name", "Old Description"));

        service.updateTask("1", "New Name", "New Description");

        Task updated = service.getTask("1");
        assertEquals("New Name", updated.getName());
        assertEquals("New Description", updated.getDescription());
    }

    @Test
    void testUpdateNonexistentTaskThrowsException() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTask("99", "Name", "Description");
        });
    }

    @Test
    void testUpdateWithNullValuesThrowsException() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Task Name", "Task Description"));

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTask("1", null, "Description");
        });
    }
}